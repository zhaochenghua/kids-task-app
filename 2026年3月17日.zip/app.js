/* ============================================================
   儿童每日任务打卡积分助手 - 应用逻辑 (服务器同步版本)
   ============================================================ */

'use strict';

// ============================================================
// 常量 & 配置
// ============================================================

const WEEKDAYS      = ['周日','周一','周二','周三','周四','周五','周六'];
const MONTHS        = ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'];

// 任务卡片颜色池
const TASK_COLORS = [
  '#FF6B6B','#4ECDC4','#A29BFE','#FDCB6E',
  '#55EFC4','#FD79A8','#74B9FF','#00CEC9',
  '#E17055','#6C5CE7','#00B894','#E84393',
];

// 可选 Emoji 列表
const EMOJI_LIST = [
  '📚','✏️','🎒','🏃','🛁','🦷','🥗','🥛',
  '🎵','🎨','🧩','🎮','🌿','🐾','🌞','💪',
  '🧹','🛏️','👕','🍎','💧','😴','📖','🎯',
  '🏊','🚴','⚽','🎸','🎹','🖥️','🧪','🌈',
  '🦁','🐶','🐱','🐸','🦋','🌸','⭐','🏆',
];

// 鼓励语
const PRAISE_WORDS = [
  '太棒了！', '真厉害！', '做到了！', '超级棒！',
  '好样的！', '了不起！', '加油加油！', '完美！',
  '你最棒！', '继续努力！', '棒棒哒！', '厉害了！',
];

// ============================================================
// 音效系统 (Web Audio API)
// ============================================================

const audioContext = new (window.AudioContext || window.webkitAudioContext)();

// 播放音效函数
function playSound(type) {
  if (audioContext.state === 'suspended') {
    audioContext.resume();
  }

  const oscillator = audioContext.createOscillator();
  const gainNode = audioContext.createGain();

  oscillator.connect(gainNode);
  gainNode.connect(audioContext.destination);

  const now = audioContext.currentTime;

  switch (type) {
    case 'check': // 任务打卡成功
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(523.25, now); // C5
      oscillator.frequency.exponentialRampToValueAtTime(1046.5, now + 0.1); // C6
      gainNode.gain.setValueAtTime(0.3, now);
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
      oscillator.start(now);
      oscillator.stop(now + 0.3);
      break;

    case 'uncheck': // 取消打卡
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(440, now); // A4
      oscillator.frequency.exponentialRampToValueAtTime(220, now + 0.15); // A3
      gainNode.gain.setValueAtTime(0.2, now);
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
      oscillator.start(now);
      oscillator.stop(now + 0.2);
      break;

    case 'complete': // 全部完成
      // 播放胜利音效序列
      playNote(523.25, 0.1, 0.2); // C5
      playNote(659.25, 0.1, 0.2); // E5
      playNote(783.99, 0.1, 0.2); // G5
      playNote(1046.50, 0.3, 0.4); // C6
      return;

    case 'click': // 按钮点击
      oscillator.type = 'triangle';
      oscillator.frequency.setValueAtTime(800, now);
      gainNode.gain.setValueAtTime(0.1, now);
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.05);
      oscillator.start(now);
      oscillator.stop(now + 0.05);
      break;

    case 'add': // 添加任务/孩子
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(659.25, now); // E5
      oscillator.frequency.exponentialRampToValueAtTime(880, now + 0.15); // A5
      gainNode.gain.setValueAtTime(0.2, now);
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
      oscillator.start(now);
      oscillator.stop(now + 0.2);
      break;

    case 'delete': // 删除
      oscillator.type = 'sawtooth';
      oscillator.frequency.setValueAtTime(300, now);
      oscillator.frequency.exponentialRampToValueAtTime(100, now + 0.2);
      gainNode.gain.setValueAtTime(0.15, now);
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
      oscillator.start(now);
      oscillator.stop(now + 0.2);
      break;

    case 'switch': // 切换孩子
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(440, now);
      gainNode.gain.setValueAtTime(0.15, now);
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
      oscillator.start(now);
      oscillator.stop(now + 0.1);
      break;
  }
}

// 播放单个音符辅助函数
function playNote(frequency, duration, delay) {
  const osc = audioContext.createOscillator();
  const gain = audioContext.createGain();
  osc.connect(gain);
  gain.connect(audioContext.destination);

  const now = audioContext.currentTime + delay;
  osc.type = 'sine';
  osc.frequency.value = frequency;
  gain.gain.setValueAtTime(0.3, now);
  gain.gain.exponentialRampToValueAtTime(0.01, now + duration);

  osc.start(now);
  osc.stop(now + duration);
}

// ============================================================
// 工具函数
// ============================================================

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

function formatDate(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  return `${d.getFullYear()}年${MONTHS[d.getMonth()]}${d.getDate()}日 ${WEEKDAYS[d.getDay()]}`;
}

function formatDateShort(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  return `${MONTHS[d.getMonth()]}${d.getDate()}日`;
}

function randomItem(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function escapeHtml(str) {
  return str.replace(/&/g,'&').replace(/</g,'<').replace(/>/g,'>');
}

// ============================================================
// 服务器通信层
// ============================================================

let socket = null;
let appData = null;
let isConnected = false;
let pendingUpdates = [];

// 初始化 Socket.IO 连接
function initSocket() {
  socket = io();

  socket.on('connect', () => {
    console.log('✅ 已连接到服务器');
    isConnected = true;
    // 请求同步数据
    socket.emit('requestSync');
  });

  socket.on('disconnect', () => {
    console.log('❌ 与服务器断开连接');
    isConnected = false;
  });

  // 接收服务器数据更新
  socket.on('dataUpdated', (data) => {
    console.log('📥 收到数据更新');
    appData = data;
    currentChild = getCurrentChild();
    ensureTodayChecks();
    renderAll();
  });
}

// 发送数据更新到服务器
function syncToServer() {
  if (isConnected && socket) {
    socket.emit('updateData', appData);
  }
}

// API 调用辅助函数
async function apiCall(method, endpoint, data = null) {
  try {
    const options = {
      method,
      headers: { 'Content-Type': 'application/json' },
    };
    if (data) options.body = JSON.stringify(data);

    const response = await fetch(`/api${endpoint}`, options);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.json();
  } catch (e) {
    console.error('API 调用失败:', e);
    return null;
  }
}

// ============================================================
// 应用状态
// ============================================================

let currentChild = null;
let allDoneShownToday = false;

// 获取当前孩子
function getCurrentChild() {
  if (!appData) return null;
  return appData.children.find(c => c.id === appData.currentChildId) || appData.children[0];
}

// 切换孩子
function switchChild(childId) {
  if (!appData) return;
  appData.currentChildId = childId;
  syncToServer();
  currentChild = getCurrentChild();
  allDoneShownToday = false;
  ensureTodayChecks();
  renderAll();
}

// 添加新孩子
async function addChild(name) {
  const result = await apiCall('POST', '/children', { name });
  if (result && result.success) {
    // 初始化三积分系统
    const child = result.child;
    if (child) {
      child.lifetimeScore = 0;  // 总积分
      child.cycleScore = 0;     // 周期积分
      // dailyScore 是计算得出的，不需要存储
    }
    return child;
  }
  return null;
}

// 获取今日积分（计算得出）
function getDailyScore(child) {
  if (!child) return 0;
  const t = today();
  const checks = child.dailyChecks[t] || {};
  let daily = 0;
  child.tasks.forEach(task => {
    if (checks[task.id]) {
      daily += task.points;
    }
  });
  // 检查是否全部完成，加上奖励
  const total = child.tasks.length;
  const done = child.tasks.filter(tk => checks[tk.id]).length;
  if (done === total && total > 0) {
    daily += parseInt(child.bonusPoints) || 0;
  }
  return daily;
}

// 初始化孩子的积分系统（用于旧数据迁移）
function initChildScoreSystem(child) {
  if (!child.lifetimeScore && child.lifetimeScore !== 0) {
    child.lifetimeScore = child.totalScore || 0;
  }
  if (!child.cycleScore && child.cycleScore !== 0) {
    child.cycleScore = child.totalScore || 0;
  }
  // 保持 totalScore 兼容旧代码
  if (!child.totalScore) {
    child.totalScore = 0;
  }
}

// 删除孩子
async function removeChild(childId) {
  if (appData.children.length <= 1) return false;

  const result = await apiCall('DELETE', `/children/${childId}`);
  if (result && result.success) {
    appData.children = appData.children.filter(c => c.id !== childId);
    if (appData.currentChildId === childId) {
      appData.currentChildId = appData.children[0].id;
    }
    syncToServer();
    return true;
  }
  return false;
}

// 确保今日打卡记录存在
function ensureTodayChecks() {
  if (!currentChild) return;
  const t = today();
  if (!currentChild.dailyChecks[t]) {
    currentChild.dailyChecks[t] = {};
    currentChild.tasks.forEach(task => {
      currentChild.dailyChecks[t][task.id] = false;
    });
    syncToServer();
  }
}

// ============================================================
// DOM 引用
// ============================================================

const $ = id => document.getElementById(id);

const els = {
  app:              $('app'),
  dateDisplay:      $('dateDisplay'),
  totalScore:       $('totalScore'),
  childName:        $('childName'),
  progressFill:     $('progressFill'),
  progressText:     $('progressText'),
  streakInfo:       $('streakInfo'),
  taskList:         $('taskList'),
  emptyHint:        $('emptyHint'),

  // 庆祝
  celebrateOverlay: $('celebrateOverlay'),
  celebrateEmoji:   $('celebrateEmoji'),
  celebrateText:    $('celebrateText'),
  celebrateSub:     $('celebrateSub'),

  // 全部完成
  allDoneOverlay:   $('allDoneOverlay'),
  bonusPoints:      $('bonusPoints'),
  allDoneClose:     $('allDoneClose'),

  // 设置
  openSettings:     $('openSettings'),
  settingsModal:    $('settingsModal'),
  closeSettings:    $('closeSettings'),
  selectChild:      $('selectChild'),
  inputChildName:   $('inputChildName'),
  inputBonus:       $('inputBonus'),
  taskEditorList:   $('taskEditorList'),
  addTaskBtn:       $('addTaskBtn'),
  clearAllScores:   $('clearAllScores'),
  saveSettings:     $('saveSettings'),

  // 历史
  openHistory:      $('openHistory'),
  historyModal:     $('historyModal'),
  closeHistory:     $('closeHistory'),
  historyTotalScore:$('historyTotalScore'),
  historyList:      $('historyList'),

  // 孩子切换
  switchChild:      $('switchChild'),
  childSwitchModal: $('childSwitchModal'),
  closeChildSwitch: $('closeChildSwitch'),
  childList:        $('childList'),
  addChildBtn:      $('addChildBtn'),

  // 并列视图
  splitViewBtn:     $('splitViewBtn'),
  splitViewContainer: $('splitViewContainer'),

  // 并列显示选择面板
  splitSelectModal: $('splitSelectModal'),
  closeSplitSelect: $('closeSplitSelect'),
  splitSelectList:  $('splitSelectList'),
  confirmSplitSelect: $('confirmSplitSelect'),

  // 左右切换按钮
  navPrev:          $('navPrev'),
  navNext:          $('navNext'),

  // 确认框
  confirmModal:     $('confirmModal'),
  confirmText:      $('confirmText'),
  confirmYes:       $('confirmYes'),
  confirmNo:        $('confirmNo'),
};

// ============================================================
// 渲染函数
// ============================================================

function renderAll() {
  if (!appData || !currentChild) return;
  renderHeader();
  renderHero();
  renderTasks();
  updateNavButtons();
}

// 更新左右切换按钮的显示状态
function updateNavButtons() {
  if (!appData || !els.navPrev || !els.navNext) return;

  // 如果只有一个孩子，隐藏切换按钮
  if (appData.children.length <= 1) {
    els.navPrev.classList.add('hidden');
    els.navNext.classList.add('hidden');
    return;
  }

  // 显示切换按钮
  els.navPrev.classList.remove('hidden');
  els.navNext.classList.remove('hidden');
}

// 切换到上一个孩子
function switchToPrevChild() {
  if (!appData || appData.children.length <= 1) return;

  const currentIndex = appData.children.findIndex(c => c.id === appData.currentChildId);
  const prevIndex = currentIndex > 0 ? currentIndex - 1 : appData.children.length - 1;
  const prevChildId = appData.children[prevIndex].id;

  playSound('switch');
  switchChild(prevChildId);
}

// 切换到下一个孩子
function switchToNextChild() {
  if (!appData || appData.children.length <= 1) return;

  const currentIndex = appData.children.findIndex(c => c.id === appData.currentChildId);
  const nextIndex = currentIndex < appData.children.length - 1 ? currentIndex + 1 : 0;
  const nextChildId = appData.children[nextIndex].id;

  playSound('switch');
  switchChild(nextChildId);
}

function renderHeader() {
  const now = new Date();
  els.dateDisplay.textContent =
    `${now.getFullYear()}年${MONTHS[now.getMonth()]}${now.getDate()}日 ${WEEKDAYS[now.getDay()]}`;
  // 显示周期积分（兼容旧数据）
  const displayScore = currentChild.cycleScore !== undefined ? currentChild.cycleScore : (currentChild.totalScore || 0);
  els.totalScore.textContent = displayScore;
}

function renderHero() {
  els.childName.textContent = currentChild.name + ' 加油！';

  const t = today();
  const checks = currentChild.dailyChecks[t] || {};
  const total = currentChild.tasks.length;
  const done  = currentChild.tasks.filter(task => checks[task.id]).length;
  const pct   = total > 0 ? Math.round((done / total) * 100) : 0;
  
  // 计算今日积分
  const dailyScore = getDailyScore(currentChild);
  // 获取周期积分
  const cycleScore = currentChild.cycleScore !== undefined ? currentChild.cycleScore : (currentChild.totalScore || 0);
  // 获取总积分
  const lifetimeScore = currentChild.lifetimeScore !== undefined ? currentChild.lifetimeScore : (currentChild.totalScore || 0);

  els.progressFill.style.width = pct + '%';
  els.progressText.textContent = `今日完成 ${done} / ${total} 项任务 · 今日 ${dailyScore} 分`;
  els.streakInfo.textContent   = `🔥 连续打卡 ${currentChild.streak} 天 · 总积分 ${lifetimeScore}`;
}

function renderTasks() {
  const t = today();
  const checks = currentChild.dailyChecks[t] || {};

  if (currentChild.tasks.length === 0) {
    els.taskList.innerHTML = '';
    els.emptyHint.style.display = 'block';
    return;
  }
  els.emptyHint.style.display = 'none';

  els.taskList.innerHTML = currentChild.tasks.map((task, idx) => {
    const isDone = !!checks[task.id];
    const color  = task.color || TASK_COLORS[idx % TASK_COLORS.length];
    return `
      <div class="task-card ${isDone ? 'done' : ''} task-card-enter"
           style="--task-color: ${color}"
           data-id="${task.id}"
           role="button"
           tabindex="0"
           aria-label="${task.name}，${task.points}积分${isDone ? '，已完成' : ''}">
        <div class="task-emoji">${task.emoji || '⭐'}</div>
        <div class="task-info">
          <div class="task-name">${escapeHtml(task.name)}</div>
          <div class="task-points">奖励 <span>${task.points}</span> 积分</div>
        </div>
        <div class="task-check">${isDone ? '✅' : ''}</div>
      </div>
    `;
  }).join('');

  // 绑定点击事件
  els.taskList.querySelectorAll('.task-card').forEach(card => {
    card.addEventListener('click', () => handleTaskClick(card.dataset.id));
    card.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') handleTaskClick(card.dataset.id);
    });
  });
}

// ============================================================
// 任务打卡逻辑
// ============================================================

async function handleTaskClick(taskId) {
  const t = today();
  ensureTodayChecks();

  const checks = currentChild.dailyChecks[t];
  const task   = currentChild.tasks.find(tk => tk.id === taskId);
  if (!task) return;

  const wasDone = !!checks[taskId];

  // 检查取消前是否全部完成
  const total = currentChild.tasks.length;
  const doneBefore = currentChild.tasks.filter(tk => checks[tk.id]).length;
  const wasAllDone = doneBefore === total && total > 0;

  // 初始化积分系统（兼容旧数据）
  initChildScoreSystem(currentChild);

  if (wasDone) {
    // 取消打卡
    checks[taskId] = false;
    
    // 扣减周期积分和总积分
    currentChild.cycleScore = Math.max(0, (currentChild.cycleScore || 0) - task.points);
    currentChild.lifetimeScore = Math.max(0, (currentChild.lifetimeScore || 0) - task.points);
    currentChild.totalScore = currentChild.cycleScore; // 保持兼容
    
    // 如果之前全部完成，需要扣回额外奖励
    if (wasAllDone) {
      const bonus = parseInt(currentChild.bonusPoints) || 0;
      currentChild.cycleScore = Math.max(0, currentChild.cycleScore - bonus);
      currentChild.lifetimeScore = Math.max(0, currentChild.lifetimeScore - bonus);
      currentChild.totalScore = currentChild.cycleScore;
      allDoneShownToday = false;
      
      // 从历史记录中移除今天的记录
      const historyIndex = currentChild.scoreHistory.findIndex(h => h.date === t);
      if (historyIndex > -1) {
        currentChild.scoreHistory.splice(historyIndex, 1);
      }
      
      // 重置连续打卡（如果今天是最后完成日期）
      if (currentChild.lastCompleteDate === t) {
        currentChild.lastCompleteDate = null;
        currentChild.streak = Math.max(0, currentChild.streak - 1);
      }
    }
    
    playSound('uncheck');
  } else {
    // 完成打卡
    checks[taskId] = true;
    
    // 增加周期积分和总积分
    currentChild.cycleScore = (currentChild.cycleScore || 0) + task.points;
    currentChild.lifetimeScore = (currentChild.lifetimeScore || 0) + task.points;
    currentChild.totalScore = currentChild.cycleScore; // 保持兼容

    // 播放打卡音效
    playSound('check');

    // 显示庆祝动画
    showCelebrate(task.emoji, randomItem(PRAISE_WORDS), `+${task.points} 积分`);
    launchConfetti();
  }

  // 同步到服务器
  syncToServer();
  renderAll();

  // 检查是否全部完成
  const done  = currentChild.tasks.filter(tk => checks[tk.id]).length;

  if (done === total && total > 0 && !wasDone && !allDoneShownToday) {
    allDoneShownToday = true;
    setTimeout(() => showAllDone(), 900);
  }
}

function showAllDone() {
  // 播放全部完成音效
  playSound('complete');

  // 发放全部完成奖励
  const bonus = parseInt(currentChild.bonusPoints) || 0;
  
  // 初始化积分系统（兼容旧数据）
  initChildScoreSystem(currentChild);
  
  // 增加周期积分和总积分
  currentChild.cycleScore = (currentChild.cycleScore || 0) + bonus;
  currentChild.lifetimeScore = (currentChild.lifetimeScore || 0) + bonus;
  currentChild.totalScore = currentChild.cycleScore; // 保持兼容

  // 更新连续打卡
  updateStreak();

  // 记录历史
  const t = today();
  const checks = currentChild.dailyChecks[t] || {};
  const earned = currentChild.tasks.reduce((sum, tk) => sum + (checks[tk.id] ? tk.points : 0), 0) + bonus;
  const existing = currentChild.scoreHistory.find(h => h.date === t);
  if (!existing) {
    currentChild.scoreHistory.unshift({
      date: t,
      earned,
      tasks: currentChild.tasks.filter(tk => checks[tk.id]).length,
      total: currentChild.tasks.length,
      bonus,
    });
    if (currentChild.scoreHistory.length > 60) currentChild.scoreHistory.pop();
  }

  syncToServer();
  renderAll();

  els.bonusPoints.textContent = bonus;
  els.allDoneOverlay.style.display = 'flex';
}

function updateStreak() {
  const t = today();
  if (currentChild.lastCompleteDate === null) {
    currentChild.streak = 1;
  } else {
    const last = new Date(currentChild.lastCompleteDate + 'T00:00:00');
    const now  = new Date(t + 'T00:00:00');
    const diff = Math.round((now - last) / 86400000);
    if (diff === 1) {
      currentChild.streak += 1;
    } else if (diff > 1) {
      currentChild.streak = 1;
    }
  }
  currentChild.lastCompleteDate = t;
}

// ============================================================
// 庆祝动画
// ============================================================

let celebrateTimer = null;

function showCelebrate(emoji, text, sub) {
  els.celebrateEmoji.textContent = emoji || '🎉';
  els.celebrateText.textContent  = text;
  els.celebrateSub.textContent   = sub;

  els.celebrateOverlay.classList.add('show');

  if (celebrateTimer) clearTimeout(celebrateTimer);
  celebrateTimer = setTimeout(() => {
    els.celebrateOverlay.classList.remove('show');
  }, 1200);
}

function launchConfetti() {
  const container = document.createElement('div');
  container.className = 'confetti-container';
  document.body.appendChild(container);

  const colors = ['#FF6B6B','#4ECDC4','#FFE66D','#A29BFE','#55EFC4','#FD79A8','#74B9FF'];
  const count  = 40;

  for (let i = 0; i < count; i++) {
    const piece = document.createElement('div');
    piece.className = 'confetti-piece';
    piece.style.cssText = `
      left: ${Math.random() * 100}vw;
      background: ${randomItem(colors)};
      width: ${6 + Math.random() * 10}px;
      height: ${6 + Math.random() * 10}px;
      border-radius: ${Math.random() > 0.5 ? '50%' : '2px'};
      animation-duration: ${0.8 + Math.random() * 1.2}s;
      animation-delay: ${Math.random() * 0.4}s;
    `;
    container.appendChild(piece);
  }

  setTimeout(() => container.remove(), 2500);
}

// ============================================================
// 孩子切换面板
// ============================================================

function openChildSwitch() {
  renderChildList();
  els.childSwitchModal.style.display = 'flex';
}

function renderChildList() {
  if (!appData) return;

  els.childList.innerHTML = appData.children.map(child => {
    const isActive = child.id === appData.currentChildId;
    const firstChar = child.name.charAt(0);
    // 初始化积分系统（兼容旧数据）
    initChildScoreSystem(child);
    // 显示周期积分
    const cycleScore = child.cycleScore !== undefined ? child.cycleScore : (child.totalScore || 0);
    return `
      <div class="child-item ${isActive ? 'active' : ''}" data-id="${child.id}">
        <div class="child-item-info">
          <div class="child-avatar">${firstChar}</div>
          <div>
            <div class="child-name-text">${escapeHtml(child.name)}</div>
            <div class="child-score">⭐ ${cycleScore} 周期积分</div>
          </div>
        </div>
        <div class="child-item-check">✅</div>
      </div>
    `;
  }).join('');

  // 绑定点击事件
  els.childList.querySelectorAll('.child-item').forEach(item => {
    item.addEventListener('click', () => {
      const childId = item.dataset.id;
      if (childId !== appData.currentChildId) {
        switchChild(childId);
      }
      els.childSwitchModal.style.display = 'none';
    });

    // 长按删除
    let pressTimer;
    item.addEventListener('mousedown', () => {
      pressTimer = setTimeout(() => {
        if (appData.children.length > 1) {
          const childId = item.dataset.id;
          const child = appData.children.find(c => c.id === childId);
          showConfirm(`确定要删除 "${child.name}" 吗？\n所有数据将被清空！`, async () => {
            if (await removeChild(childId)) {
              currentChild = getCurrentChild();
              renderAll();
              renderChildList();
            }
          });
        }
      }, 800);
    });
    item.addEventListener('mouseup', () => clearTimeout(pressTimer));
    item.addEventListener('mouseleave', () => clearTimeout(pressTimer));

    // 触摸设备支持
    item.addEventListener('touchstart', (e) => {
      pressTimer = setTimeout(() => {
        if (appData.children.length > 1) {
          const childId = item.dataset.id;
          const child = appData.children.find(c => c.id === childId);
          showConfirm(`确定要删除 "${child.name}" 吗？\n所有数据将被清空！`, async () => {
            if (await removeChild(childId)) {
              currentChild = getCurrentChild();
              renderAll();
              renderChildList();
            }
          });
        }
      }, 800);
    });
    item.addEventListener('touchend', () => clearTimeout(pressTimer));
  });
}

async function handleAddChild() {
  const name = prompt('请输入新孩子的名字：', '');
  if (name && name.trim()) {
    const newChild = await addChild(name.trim());
    if (newChild) {
      switchChild(newChild.id);
      renderChildList();
    }
  }
}

// ============================================================
// 设置面板
// ============================================================

let editingTasks = [];
let activeEmojiTarget = null;

function openSettings() {
  // 填充孩子选择下拉菜单
  renderChildSelect();
  // 加载当前孩子的数据
  loadChildDataToSettings(currentChild);
  els.settingsModal.style.display = 'flex';
}

// 渲染孩子选择下拉菜单
function renderChildSelect() {
  if (!appData || !els.selectChild) return;
  
  els.selectChild.innerHTML = '<option value="">-- 选择孩子 --</option>' +
    appData.children.map(child => 
      `<option value="${child.id}" ${child.id === currentChild.id ? 'selected' : ''}>${escapeHtml(child.name)}</option>`
    ).join('');
}

// 加载指定孩子的数据到设置面板
function loadChildDataToSettings(child) {
  if (!child) return;
  editingTasks = child.tasks.map(t => ({ ...t }));
  els.inputChildName.value = child.name;
  els.inputBonus.value = child.bonusPoints;
  renderTaskEditor();
}

function renderTaskEditor() {
  els.taskEditorList.innerHTML = editingTasks.map((task, idx) => `
    <div class="task-editor-item" data-idx="${idx}">
      <span class="task-editor-emoji" data-idx="${idx}" title="点击更换图标">${task.emoji || '⭐'}</span>
      <input class="task-editor-name"
             type="text"
             value="${escapeHtml(task.name)}"
             placeholder="任务名称"
             maxlength="20"
             data-idx="${idx}" />
      <input class="task-editor-points"
             type="number"
             value="${task.points}"
             min="1" max="99"
             data-idx="${idx}" />
      <span class="task-editor-points-label">分</span>
      <button class="task-editor-delete" data-idx="${idx}" title="删除">🗑️</button>
    </div>
  `).join('');

  els.taskEditorList.querySelectorAll('.task-editor-emoji').forEach(el => {
    el.addEventListener('click', e => {
      e.stopPropagation();
      showEmojiPicker(parseInt(el.dataset.idx), el);
    });
  });

  els.taskEditorList.querySelectorAll('.task-editor-name').forEach(el => {
    el.addEventListener('input', () => {
      editingTasks[parseInt(el.dataset.idx)].name = el.value;
    });
  });

  els.taskEditorList.querySelectorAll('.task-editor-points').forEach(el => {
    el.addEventListener('input', () => {
      editingTasks[parseInt(el.dataset.idx)].points = Math.max(1, parseInt(el.value) || 1);
    });
  });

  els.taskEditorList.querySelectorAll('.task-editor-delete').forEach(el => {
    el.addEventListener('click', () => {
      editingTasks.splice(parseInt(el.dataset.idx), 1);
      renderTaskEditor();
    });
  });
}

function addNewTask() {
  const colorIdx = editingTasks.length % TASK_COLORS.length;
  editingTasks.push({
    id:     uid(),
    name:   '',
    emoji:  randomItem(EMOJI_LIST),
    points: 2,
    color:  TASK_COLORS[colorIdx],
  });
  renderTaskEditor();
  setTimeout(() => {
    const items = els.taskEditorList.querySelectorAll('.task-editor-item');
    if (items.length > 0) {
      items[items.length - 1].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      const input = items[items.length - 1].querySelector('.task-editor-name');
      if (input) input.focus();
    }
  }, 50);
}

function saveSettings() {
  const name = els.inputChildName.value.trim();
  if (!name) {
    els.inputChildName.focus();
    els.inputChildName.style.borderColor = 'var(--primary)';
    return;
  }

  const validTasks = editingTasks.filter(t => t.name.trim() !== '');
  validTasks.forEach((t, idx) => {
    if (!t.color) t.color = TASK_COLORS[idx % TASK_COLORS.length];
    t.name = t.name.trim();
    t.points = Math.max(1, parseInt(t.points) || 1);
  });

  currentChild.name        = name;
  currentChild.bonusPoints = Math.max(0, parseInt(els.inputBonus.value) || 0);
  currentChild.tasks       = validTasks;

  // 重置今日打卡
  const t = today();
  currentChild.dailyChecks[t] = {};
  currentChild.tasks.forEach(task => {
    currentChild.dailyChecks[t][task.id] = false;
  });
  allDoneShownToday = false;

  syncToServer();
  renderAll();
  els.settingsModal.style.display = 'none';
}

// ============================================================
// Emoji 选择器
// ============================================================

let emojiPickerEl = null;

function showEmojiPicker(taskIdx, anchorEl) {
  closeEmojiPicker();
  activeEmojiTarget = taskIdx;

  emojiPickerEl = document.createElement('div');
  emojiPickerEl.className = 'emoji-picker';
  emojiPickerEl.innerHTML = EMOJI_LIST.map(e =>
    `<div class="emoji-picker-item" data-emoji="${e}">${e}</div>`
  ).join('');

  document.body.appendChild(emojiPickerEl);

  const rect = anchorEl.getBoundingClientRect();
  let top  = rect.bottom + 8;
  let left = rect.left;

  const pickerW = 320;
  const pickerH = 200;
  if (left + pickerW > window.innerWidth - 10) left = window.innerWidth - pickerW - 10;
  if (top + pickerH > window.innerHeight - 10) top = rect.top - pickerH - 8;

  emojiPickerEl.style.top  = top  + 'px';
  emojiPickerEl.style.left = left + 'px';

  emojiPickerEl.querySelectorAll('.emoji-picker-item').forEach(item => {
    item.addEventListener('click', e => {
      e.stopPropagation();
      editingTasks[activeEmojiTarget].emoji = item.dataset.emoji;
      renderTaskEditor();
      closeEmojiPicker();
    });
  });

  setTimeout(() => {
    document.addEventListener('click', closeEmojiPicker, { once: true });
  }, 0);
}

function closeEmojiPicker() {
  if (emojiPickerEl) {
    emojiPickerEl.remove();
    emojiPickerEl = null;
  }
}

// ============================================================
// 并列视图
// ============================================================

let isSplitView = false;
let selectedSplitChildren = [];

function toggleSplitView() {
  if (!appData || appData.children.length < 2) {
    showConfirm('需要至少两个孩子才能使用并列显示功能\n是否现在添加第二个孩子？', () => {
      handleAddChild();
    });
    return;
  }

  if (isSplitView) {
    closeSplitView();
    return;
  }

  if (appData.children.length >= 3) {
    openSplitSelectPanel();
  } else {
    selectedSplitChildren = [appData.children[0].id, appData.children[1].id];
    showSplitView();
  }
}

function openSplitSelectPanel() {
  selectedSplitChildren = [];
  renderSplitSelectList();
  els.splitSelectModal.style.display = 'flex';
}

function renderSplitSelectList() {
  const hintEl = document.querySelector('.split-select-hint');
  if (hintEl) {
    hintEl.textContent = `💡 已选择 ${selectedSplitChildren.length} 个孩子，点击确认显示`;
  }

  els.splitSelectList.innerHTML = appData.children.map(child => {
    const isSelected = selectedSplitChildren.includes(child.id);
    const firstChar = child.name.charAt(0);
    // 初始化积分系统（兼容旧数据）
    initChildScoreSystem(child);
    // 显示周期积分
    const cycleScore = child.cycleScore !== undefined ? child.cycleScore : (child.totalScore || 0);
    return `
      <div class="split-select-item ${isSelected ? 'selected' : ''}" data-id="${child.id}">
        <div class="split-select-checkbox">${isSelected ? '✅' : ''}</div>
        <div class="split-select-avatar">${firstChar}</div>
        <div class="split-select-name">${escapeHtml(child.name)}</div>
        <div class="split-select-score">⭐ ${cycleScore}</div>
      </div>
    `;
  }).join('');

  els.splitSelectList.querySelectorAll('.split-select-item').forEach(item => {
    item.addEventListener('click', () => {
      const childId = item.dataset.id;
      const idx = selectedSplitChildren.indexOf(childId);

      if (idx > -1) {
        selectedSplitChildren.splice(idx, 1);
      } else {
        selectedSplitChildren.push(childId);
      }

      renderSplitSelectList();
    });
  });
}

function confirmSplitSelection() {
  if (selectedSplitChildren.length < 2) {
    alert('请至少选择 2 个孩子进行并列显示');
    return;
  }
  els.splitSelectModal.style.display = 'none';
  showSplitView();
}

function showSplitView() {
  isSplitView = true;
  renderSplitView();
  els.splitViewContainer.style.display = 'flex';
  els.app.style.display = 'none';
  els.splitViewBtn.classList.add('active');
}

function renderSplitView() {
  els.splitViewContainer.setAttribute('data-count', selectedSplitChildren.length);
  els.splitViewContainer.innerHTML = '';

  selectedSplitChildren.forEach(childId => {
    const child = appData.children.find(c => c.id === childId);
    if (child) {
      const panel = document.createElement('div');
      panel.className = 'split-view-child-panel';
      panel.innerHTML = renderChildPanel(child);
      els.splitViewContainer.appendChild(panel);
      bindSplitViewTasks(child, panel);
    }
  });

  const closeBtn = document.createElement('button');
  closeBtn.className = 'split-view-close';
  closeBtn.textContent = '👤 单视图模式';
  closeBtn.onclick = closeSplitView;
  els.splitViewContainer.appendChild(closeBtn);
}

function renderChildPanel(child) {
  const t = today();
  const checks = child.dailyChecks[t] || {};
  const total = child.tasks.length;
  const done = child.tasks.filter(task => checks[task.id]).length;
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;
  
  // 初始化积分系统（兼容旧数据）
  initChildScoreSystem(child);
  
  // 获取三积分
  const dailyScore = getDailyScore(child);
  const cycleScore = child.cycleScore || 0;
  const lifetimeScore = child.lifetimeScore || 0;

  const tasksHtml = child.tasks.map((task, idx) => {
    const isDone = !!checks[task.id];
    const color = task.color || TASK_COLORS[idx % TASK_COLORS.length];
    return `
      <div class="task-card ${isDone ? 'done' : ''}"
           style="--task-color: ${color}"
           data-task-id="${task.id}"
           data-child-id="${child.id}"
           role="button">
        <div class="task-emoji">${task.emoji || '⭐'}</div>
        <div class="task-info">
          <div class="task-name">${escapeHtml(task.name)}</div>
          <div class="task-points">奖励 <span>${task.points}</span> 积分</div>
        </div>
        <div class="task-check">${isDone ? '✅' : ''}</div>
      </div>
    `;
  }).join('');

  return `
    <div class="split-view-child">
      <div class="split-view-header">
        <div class="split-view-name">${escapeHtml(child.name)}</div>
        <div class="split-view-scores">
          <div class="split-view-score-badge cycle">
            <span>⭐</span>
            <span>${cycleScore}</span>
          </div>
          <div class="split-view-score-badge lifetime">
            <span>🏆</span>
            <span>${lifetimeScore}</span>
          </div>
        </div>
      </div>
      <div class="split-view-progress">
        <div class="split-view-progress-bar">
          <div class="split-view-progress-fill" style="width: ${pct}%"></div>
        </div>
        <div class="split-view-progress-text">今日完成 ${done} / ${total} 项任务 · 今日 ${dailyScore} 分</div>
      </div>
      <div class="split-view-tasks">
        ${tasksHtml}
      </div>
      <button class="split-view-history-btn" data-child-id="${child.id}">
        🏆 积分记录
      </button>
    </div>
  `;
}

function bindSplitViewTasks(child, panel) {
  const cards = panel.querySelectorAll('.task-card');

  cards.forEach(card => {
    card.addEventListener('click', () => {
      const taskId = card.dataset.taskId;
      handleSplitViewTaskClick(child, taskId);
    });
  });

  // 绑定积分记录按钮
  const historyBtn = panel.querySelector('.split-view-history-btn');
  if (historyBtn) {
    historyBtn.addEventListener('click', () => {
      showChildHistory(child);
    });
  }
}

// 显示指定孩子的积分历史
function showChildHistory(child) {
  // 初始化积分系统（兼容旧数据）
  initChildScoreSystem(child);
  
  // 获取三积分
  const dailyScore = getDailyScore(child);
  const cycleScore = child.cycleScore || 0;
  const lifetimeScore = child.lifetimeScore || 0;
  
  // 显示三积分信息
  els.historyTotalScore.innerHTML = `
    <div class="score-breakdown">
      <span class="score-daily">今日: ${dailyScore}</span>
      <span class="score-cycle">周期: ${cycleScore}</span>
      <span class="score-lifetime">总积分: ${lifetimeScore}</span>
    </div>
  `;

  if (child.scoreHistory.length === 0) {
    els.historyList.innerHTML = '<div class="history-empty">还没有积分记录哦，快去完成任务吧！🌟</div>';
  } else {
    els.historyList.innerHTML = child.scoreHistory.map(item => `
      <div class="history-item">
        <div>
          <div class="history-item-date">${formatDate(item.date)}</div>
          <div class="history-item-detail">完成 ${item.tasks}/${item.total} 项任务${item.bonus > 0 ? `，全完成奖励 +${item.bonus}` : ''}</div>
        </div>
        <div class="history-item-score">+${item.earned} ⭐</div>
      </div>
    `).join('');
  }

  els.historyModal.style.display = 'flex';
}

async function handleSplitViewTaskClick(child, taskId) {
  const t = today();

  if (!child.dailyChecks[t]) {
    child.dailyChecks[t] = {};
    child.tasks.forEach(task => {
      child.dailyChecks[t][task.id] = false;
    });
  }

  const checks = child.dailyChecks[t];
  const task = child.tasks.find(tk => tk.id === taskId);
  if (!task) return;

  const wasChecked = checks[taskId];
  
  // 检查取消前是否全部完成
  const total = child.tasks.length;
  const doneBefore = child.tasks.filter(tk => checks[tk.id]).length;
  const wasAllDone = doneBefore === total && total > 0;

  // 初始化积分系统（兼容旧数据）
  initChildScoreSystem(child);

  checks[taskId] = !wasChecked;

  if (!wasChecked) {
    // 增加周期积分和总积分
    child.cycleScore = (child.cycleScore || 0) + task.points;
    child.lifetimeScore = (child.lifetimeScore || 0) + task.points;
    child.totalScore = child.cycleScore; // 保持兼容
    
    playSound('check');
    showCelebrate(task.emoji, randomItem(PRAISE_WORDS), `+${task.points} 积分`);
    launchConfetti();
  } else {
    // 扣减周期积分和总积分
    child.cycleScore = Math.max(0, (child.cycleScore || 0) - task.points);
    child.lifetimeScore = Math.max(0, (child.lifetimeScore || 0) - task.points);
    child.totalScore = child.cycleScore; // 保持兼容
    
    // 如果之前全部完成，需要扣回额外奖励
    if (wasAllDone) {
      const bonus = parseInt(child.bonusPoints) || 0;
      child.cycleScore = Math.max(0, child.cycleScore - bonus);
      child.lifetimeScore = Math.max(0, child.lifetimeScore - bonus);
      child.totalScore = child.cycleScore;
      
      // 从历史记录中移除今天的记录
      const historyIndex = child.scoreHistory.findIndex(h => h.date === t);
      if (historyIndex > -1) {
        child.scoreHistory.splice(historyIndex, 1);
      }
      
      // 重置连续打卡（如果今天是最后完成日期）
      if (child.lastCompleteDate === t) {
        child.lastCompleteDate = null;
        child.streak = Math.max(0, child.streak - 1);
      }
    }
    
    playSound('uncheck');
  }

  // 检查是否全部完成
  const done = child.tasks.filter(tk => checks[tk.id]).length;

  if (done === total && total > 0 && !wasChecked) {
    const bonus = parseInt(child.bonusPoints) || 0;
    
    // 增加周期积分和总积分
    child.cycleScore = (child.cycleScore || 0) + bonus;
    child.lifetimeScore = (child.lifetimeScore || 0) + bonus;
    child.totalScore = child.cycleScore; // 保持兼容

    if (child.lastCompleteDate === null) {
      child.streak = 1;
    } else {
      const last = new Date(child.lastCompleteDate + 'T00:00:00');
      const now = new Date(t + 'T00:00:00');
      const diff = Math.round((now - last) / 86400000);
      if (diff === 1) {
        child.streak += 1;
      } else if (diff > 1) {
        child.streak = 1;
      }
    }
    child.lastCompleteDate = t;

    const earned = child.tasks.reduce((sum, tk) => sum + (checks[tk.id] ? tk.points : 0), 0) + bonus;
    const existing = child.scoreHistory.find(h => h.date === t);
    if (!existing) {
      child.scoreHistory.unshift({
        date: t,
        earned,
        tasks: child.tasks.filter(tk => checks[tk.id]).length,
        total: child.tasks.length,
        bonus,
      });
      if (child.scoreHistory.length > 60) child.scoreHistory.pop();
    }

    setTimeout(() => {
      els.bonusPoints.textContent = bonus;
      els.allDoneOverlay.style.display = 'flex';
    }, 500);
  }

  syncToServer();
  renderSplitView();
}

function closeSplitView() {
  isSplitView = false;
  els.splitViewContainer.style.display = 'none';
  els.app.style.display = 'flex';
  els.splitViewBtn.classList.remove('active');

  const closeBtn = els.splitViewContainer.querySelector('.split-view-close');
  if (closeBtn) closeBtn.remove();

  currentChild = getCurrentChild();
  renderAll();
}

// ============================================================
// 积分历史
// ============================================================

function openHistory() {
  // 初始化积分系统（兼容旧数据）
  initChildScoreSystem(currentChild);
  
  // 获取三积分
  const dailyScore = getDailyScore(currentChild);
  const cycleScore = currentChild.cycleScore || 0;
  const lifetimeScore = currentChild.lifetimeScore || 0;
  
  // 显示三积分信息
  els.historyTotalScore.innerHTML = `
    <div class="score-breakdown">
      <span class="score-daily">今日: ${dailyScore}</span>
      <span class="score-cycle">周期: ${cycleScore}</span>
      <span class="score-lifetime">总积分: ${lifetimeScore}</span>
    </div>
  `;

  if (currentChild.scoreHistory.length === 0) {
    els.historyList.innerHTML = '<div class="history-empty">还没有积分记录哦，快去完成任务吧！🌟</div>';
  } else {
    els.historyList.innerHTML = currentChild.scoreHistory.map(item => `
      <div class="history-item">
        <div>
          <div class="history-item-date">${formatDate(item.date)}</div>
          <div class="history-item-detail">完成 ${item.tasks}/${item.total} 项任务${item.bonus > 0 ? `，全完成奖励 +${item.bonus}` : ''}</div>
        </div>
        <div class="history-item-score">+${item.earned} ⭐</div>
      </div>
    `).join('');
  }

  els.historyModal.style.display = 'flex';
}

// ============================================================
// 清空周期积分
// ============================================================

function clearAllScores() {
  showConfirm('确定要清空当前孩子的周期积分吗？\n总积分将保留，此操作不可恢复！', () => {
    // 初始化积分系统
    initChildScoreSystem(currentChild);
    
    // 只清空周期积分，保留总积分
    currentChild.cycleScore = 0;
    currentChild.totalScore = 0; // 保持兼容
    currentChild.scoreHistory = [];
    currentChild.streak = 0;
    currentChild.lastCompleteDate = null;
    
    syncToServer();
    renderAll();
    els.settingsModal.style.display = 'none';
  });
}

// ============================================================
// 重置总积分
// ============================================================

function resetLifetimeScore() {
  showConfirm('确定要重置总积分吗？\n\n这将清空所有累计的总积分，周期积分和连续打卡记录也会被清空！\n此操作不可恢复！', () => {
    // 初始化积分系统
    initChildScoreSystem(currentChild);
    
    // 清空所有积分
    currentChild.lifetimeScore = 0;
    currentChild.cycleScore = 0;
    currentChild.totalScore = 0;
    currentChild.scoreHistory = [];
    currentChild.streak = 0;
    currentChild.lastCompleteDate = null;
    
    syncToServer();
    renderAll();
    els.settingsModal.style.display = 'none';
    
    // 显示成功提示
    showCelebrate('🔄', '总积分已重置！', '所有积分已清零');
  });
}

// ============================================================
// 开启新周期
// ============================================================

function startNewCycle() {
  const childCount = appData.children.length;
  const confirmMsg = childCount === 1 
    ? '确定要开启新周期吗？\n\n这将清空周期积分和连续打卡记录，开始新的积分周期！\n总积分将保留。'
    : `确定要开启新周期吗？\n\n这将清空所有 ${childCount} 个孩子的周期积分和连续打卡记录，开始新的积分周期！\n总积分将保留。`;
  
  showConfirm(confirmMsg, () => {
    // 清空所有孩子的周期数据
    appData.children.forEach(child => {
      // 初始化积分系统
      initChildScoreSystem(child);
      
      // 只重置周期积分，保留总积分
      child.cycleScore = 0;
      child.totalScore = 0; // 保持兼容
      child.scoreHistory = [];
      child.streak = 0;
      child.lastCompleteDate = null;
      
      // 重置今日打卡状态
      const t = today();
      child.dailyChecks[t] = {};
      child.tasks.forEach(task => {
        child.dailyChecks[t][task.id] = false;
      });
    });
    
    // 播放特殊音效
    playSound('complete');
    
    // 同步到服务器
    syncToServer();
    
    // 重新渲染
    allDoneShownToday = false;
    renderAll();
    
    // 关闭设置面板
    els.settingsModal.style.display = 'none';
    
    // 显示成功提示
    setTimeout(() => {
      showCelebrate('🎉', '新周期已开始！', '周期积分已重置，总积分保留');
      launchConfetti();
    }, 300);
  });
}

// ============================================================
// 确认对话框
// ============================================================

let confirmCallback = null;

function showConfirm(text, onYes) {
  els.confirmText.textContent = text;
  confirmCallback = onYes;
  els.confirmModal.style.display = 'flex';
}

// ============================================================
// 自动日期切换检测
// ============================================================

let lastCheckedDate = today();

function checkDateChange() {
  const current = today();
  if (current !== lastCheckedDate) {
    lastCheckedDate = current;
    ensureTodayChecks();
    allDoneShownToday = false;
    renderAll();
  }
}

setInterval(checkDateChange, 60000);

// ============================================================
// 事件绑定
// ============================================================

function bindEvents() {
  // 并列视图
  els.splitViewBtn.addEventListener('click', () => {
    playSound('click');
    toggleSplitView();
  });
  els.closeSplitSelect.addEventListener('click', () => {
    playSound('click');
    els.splitSelectModal.style.display = 'none';
  });
  els.confirmSplitSelect.addEventListener('click', () => {
    playSound('click');
    confirmSplitSelection();
  });
  els.splitSelectModal.addEventListener('click', e => {
    if (e.target === els.splitSelectModal) els.splitSelectModal.style.display = 'none';
  });

  // 孩子切换
  els.switchChild.addEventListener('click', () => {
    playSound('click');
    openChildSwitch();
  });
  els.closeChildSwitch.addEventListener('click', () => {
    playSound('click');
    els.childSwitchModal.style.display = 'none';
  });
  els.childSwitchModal.addEventListener('click', e => {
    if (e.target === els.childSwitchModal) els.childSwitchModal.style.display = 'none';
  });
  els.addChildBtn.addEventListener('click', () => {
    playSound('add');
    handleAddChild();
  });

  // 设置
  els.openSettings.addEventListener('click', () => {
    playSound('click');
    openSettings();
  });
  els.closeSettings.addEventListener('click', () => {
    playSound('click');
    els.settingsModal.style.display = 'none';
    closeEmojiPicker();
  });
  els.saveSettings.addEventListener('click', () => {
    playSound('click');
    saveSettings();
  });
  els.addTaskBtn.addEventListener('click', () => {
    playSound('add');
    addNewTask();
  });
  els.clearAllScores.addEventListener('click', () => {
    playSound('delete');
    clearAllScores();
  });

  // 重置总积分按钮
  const resetLifetimeScoreBtn = document.getElementById('resetLifetimeScore');
  if (resetLifetimeScoreBtn) {
    resetLifetimeScoreBtn.addEventListener('click', () => {
      playSound('delete');
      resetLifetimeScore();
    });
  }

  // 开启新周期按钮
  const startNewCycleBtn = document.getElementById('startNewCycle');
  if (startNewCycleBtn) {
    startNewCycleBtn.addEventListener('click', () => {
      playSound('click');
      startNewCycle();
    });
  }

  // 孩子选择下拉菜单
  if (els.selectChild) {
    els.selectChild.addEventListener('change', () => {
      playSound('switch');
      const selectedChildId = els.selectChild.value;
      if (selectedChildId) {
        const selectedChild = appData.children.find(c => c.id === selectedChildId);
        if (selectedChild) {
          currentChild = selectedChild;
          appData.currentChildId = selectedChildId;
          loadChildDataToSettings(selectedChild);
        }
      }
    });
  }

  els.settingsModal.addEventListener('click', e => {
    if (e.target === els.settingsModal) {
      els.settingsModal.style.display = 'none';
      closeEmojiPicker();
    }
  });

  // 历史
  els.openHistory.addEventListener('click', () => {
    playSound('click');
    openHistory();
  });
  els.closeHistory.addEventListener('click', () => {
    playSound('click');
    els.historyModal.style.display = 'none';
  });
  els.historyModal.addEventListener('click', e => {
    if (e.target === els.historyModal) els.historyModal.style.display = 'none';
  });

  // 全部完成关闭
  els.allDoneClose.addEventListener('click', () => {
    playSound('click');
    els.allDoneOverlay.style.display = 'none';
  });

  // 确认框
  els.confirmYes.addEventListener('click', () => {
    playSound('click');
    els.confirmModal.style.display = 'none';
    if (confirmCallback) {
      confirmCallback();
      confirmCallback = null;
    }
  });
  els.confirmNo.addEventListener('click', () => {
    playSound('click');
    els.confirmModal.style.display = 'none';
    confirmCallback = null;
  });
  els.confirmModal.addEventListener('click', e => {
    if (e.target === els.confirmModal) {
      els.confirmModal.style.display = 'none';
      confirmCallback = null;
    }
  });

  // 左右切换按钮
  if (els.navPrev) {
    els.navPrev.addEventListener('click', () => {
      switchToPrevChild();
    });
  }
  if (els.navNext) {
    els.navNext.addEventListener('click', () => {
      switchToNextChild();
    });
  }

  // 防止 iOS Safari 双击缩放
  document.addEventListener('touchend', e => {
    e.preventDefault();
    e.target.click && e.target.click();
  }, { passive: false });
}

// ============================================================
// 时钟更新
// ============================================================

function startClock() {
  function tick() {
    renderHeader();
  }
  tick();
  setInterval(tick, 60000);
}

// ============================================================
// 初始化
// ============================================================

function init() {
  // 初始化 Socket.IO 连接
  initSocket();

  // 等待数据加载
  const checkDataLoaded = setInterval(() => {
    if (appData) {
      clearInterval(checkDataLoaded);
      currentChild = getCurrentChild();
      ensureTodayChecks();
      bindEvents();
      renderAll();
      startClock();

      // 检查今天是否已经全部完成
      const t = today();
      const checks = currentChild.dailyChecks[t] || {};
      const total  = currentChild.tasks.length;
      const done   = currentChild.tasks.filter(tk => checks[tk.id]).length;
      if (done === total && total > 0) {
        allDoneShownToday = true;
      }

      console.log('🌟 儿童任务打卡助手已启动！支持多端实时同步！');
    }
  }, 100);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
