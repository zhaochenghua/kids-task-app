/* ============================================================
   儿童每日任务打卡积分助手 - 服务端 (支持多端实时同步)
   ============================================================ */

const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data.json');

// 中间件
app.use(express.json());
app.use(express.static(__dirname));

// 数据存储
let appData = {
  children: [],
  currentChildId: null,
  lastModified: Date.now()
};

// 加载数据
function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
      appData = { ...appData, ...data };
      console.log('📂 数据已加载');
    } else {
      // 初始化默认数据
      const defaultChildId = generateId();
      appData = {
        children: [{
          id: defaultChildId,
          name: '小朋友',
          bonusPoints: 5,
          tasks: [
            { id: generateId(), name: '早起刷牙洗脸', emoji: '🦷', points: 2, color: '#4ECDC4' },
            { id: generateId(), name: '整理书包', emoji: '🎒', points: 2, color: '#A29BFE' },
            { id: generateId(), name: '完成作业', emoji: '📚', points: 5, color: '#FF6B6B' },
            { id: generateId(), name: '阅读30分钟', emoji: '📖', points: 3, color: '#FDCB6E' },
            { id: generateId(), name: '运动锻炼', emoji: '🏃', points: 3, color: '#55EFC4' },
            { id: generateId(), name: '整理房间', emoji: '🧹', points: 2, color: '#FD79A8' },
          ],
          dailyChecks: {},
          scoreHistory: [],
          totalScore: 0,
          streak: 0,
          lastCompleteDate: null,
        }],
        currentChildId: defaultChildId,
        lastModified: Date.now()
      };
      saveData();
      console.log('🆕 已创建默认数据');
    }
  } catch (e) {
    console.error('加载数据失败:', e);
  }
}

// 保存数据
function saveData() {
  try {
    appData.lastModified = Date.now();
    fs.writeFileSync(DATA_FILE, JSON.stringify(appData, null, 2));
  } catch (e) {
    console.error('保存数据失败:', e);
  }
}

// 生成唯一ID
function generateId() {
  return Math.random().toString(36).slice(2, 10);
}

// 获取今天的日期字符串
function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

// API 路由

// 获取所有数据
app.get('/api/data', (req, res) => {
  res.json(appData);
});

// 更新数据
app.post('/api/data', (req, res) => {
  appData = { ...req.body, lastModified: Date.now() };
  saveData();
  // 广播给所有连接的客户端
  io.emit('dataUpdated', appData);
  res.json({ success: true, data: appData });
});

// 获取特定孩子的数据
app.get('/api/child/:id', (req, res) => {
  const child = appData.children.find(c => c.id === req.params.id);
  if (child) {
    res.json(child);
  } else {
    res.status(404).json({ error: '孩子未找到' });
  }
});

// 更新特定孩子的数据
app.post('/api/child/:id', (req, res) => {
  const index = appData.children.findIndex(c => c.id === req.params.id);
  if (index !== -1) {
    appData.children[index] = { ...req.body, id: req.params.id };
    appData.lastModified = Date.now();
    saveData();
    io.emit('dataUpdated', appData);
    res.json({ success: true, child: appData.children[index] });
  } else {
    res.status(404).json({ error: '孩子未找到' });
  }
});

// 添加新孩子
app.post('/api/children', (req, res) => {
  const newChild = {
    id: generateId(),
    name: req.body.name || '新孩子',
    bonusPoints: 5,
    tasks: [
      { id: generateId(), name: '早起刷牙洗脸', emoji: '🦷', points: 2, color: '#4ECDC4' },
      { id: generateId(), name: '整理书包', emoji: '🎒', points: 2, color: '#A29BFE' },
      { id: generateId(), name: '完成作业', emoji: '📚', points: 5, color: '#FF6B6B' },
      { id: generateId(), name: '阅读30分钟', emoji: '📖', points: 3, color: '#FDCB6E' },
      { id: generateId(), name: '运动锻炼', emoji: '🏃', points: 3, color: '#55EFC4' },
      { id: generateId(), name: '整理房间', emoji: '🧹', points: 2, color: '#FD79A8' },
    ],
    dailyChecks: {},
    scoreHistory: [],
    totalScore: 0,
    streak: 0,
    lastCompleteDate: null,
  };
  appData.children.push(newChild);
  appData.lastModified = Date.now();
  saveData();
  io.emit('dataUpdated', appData);
  res.json({ success: true, child: newChild });
});

// 删除孩子
app.delete('/api/children/:id', (req, res) => {
  if (appData.children.length <= 1) {
    return res.status(400).json({ error: '至少保留一个孩子' });
  }
  appData.children = appData.children.filter(c => c.id !== req.params.id);
  if (appData.currentChildId === req.params.id) {
    appData.currentChildId = (appData.children[0] && appData.children[0].id) || null;
  }
  appData.lastModified = Date.now();
  saveData();
  io.emit('dataUpdated', appData);
  res.json({ success: true });
});

// 任务打卡
app.post('/api/checkin', (req, res) => {
  const { childId, taskId, checked } = req.body;
  const child = appData.children.find(c => c.id === childId);
  
  if (!child) {
    return res.status(404).json({ error: '孩子未找到' });
  }
  
  const task = child.tasks.find(t => t.id === taskId);
  if (!task) {
    return res.status(404).json({ error: '任务未找到' });
  }
  
  const t = today();
  if (!child.dailyChecks[t]) {
    child.dailyChecks[t] = {};
  }
  
  const wasChecked = child.dailyChecks[t][taskId];
  child.dailyChecks[t][taskId] = checked;
  
  // 更新积分
  if (checked && !wasChecked) {
    child.totalScore += task.points;
  } else if (!checked && wasChecked) {
    child.totalScore = Math.max(0, child.totalScore - task.points);
  }
  
  appData.lastModified = Date.now();
  saveData();
  io.emit('dataUpdated', appData);
  
  res.json({ 
    success: true, 
    child,
    pointsChanged: checked && !wasChecked ? task.points : (!checked && wasChecked ? -task.points : 0)
  });
});

// Socket.IO 连接处理
io.on('connection', (socket) => {
  console.log('🔌 客户端已连接:', socket.id);
  
  // 发送当前数据给新连接的客户端
  socket.emit('dataUpdated', appData);
  
  socket.on('disconnect', () => {
    console.log('🔌 客户端已断开:', socket.id);
  });
  
  // 客户端请求同步数据
  socket.on('requestSync', () => {
    socket.emit('dataUpdated', appData);
  });
  
  // 客户端更新数据
  socket.on('updateData', (data) => {
    appData = { ...data, lastModified: Date.now() };
    saveData();
    // 广播给所有其他客户端
    socket.broadcast.emit('dataUpdated', appData);
  });
});

// 启动服务器
loadData();
server.listen(PORT, () => {
  console.log(`
🌟 儿童每日任务打卡积分助手服务端已启动！
📱 访问地址: http://localhost:${PORT}
💾 数据文件: ${DATA_FILE}
🔌 WebSocket: ws://localhost:${PORT}
  `);
});
